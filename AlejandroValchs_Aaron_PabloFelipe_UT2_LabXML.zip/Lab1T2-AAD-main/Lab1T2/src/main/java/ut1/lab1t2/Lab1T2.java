package ut1.lab1t2;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import java.io.FileOutputStream;




public class Lab1T2 {
    public static void main(String[] args){
        try{
            //DOM
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance(); //Crea una fabrica que crea el objeto necesario para leer el XML mediante DOM.
            DocumentBuilder builder = factory.newDocumentBuilder();                //Usando la fabrica obtenemos un objeto que analiza el XML.
            
            Document doc = builder.parse(new File("imperio.xml"));                 //Cargamos el XML en la memoria y lo llamamos doc. Con esto se puede recorrer y buscar elementos dentro.
            
            doc.getDocumentElement().normalize();                                  //Normalizar aquí significa que representa los nodos del XML de manera consistente para trabajar con ellos.
            System.out.println("Elemento raíz: " + doc.getDocumentElement().getNodeName());
            
            NodeList listaImp = doc.getElementsByTagName("nave");                  //Busca todas las etiquetas nave.
            
            for (int i = 0; i < listaImp.getLength(); i++) {                       //Recorre las naves encontradas, y muestra sus datos en pantalla.
                Node nodo = listaImp.item(i);
                if (nodo.getNodeType() == Node.ELEMENT_NODE) {
                    Element elemento = (Element) nodo;
                    String id = elemento.getAttribute("id");
                    String nombre = elemento.getElementsByTagName("nombre").item(0).getTextContent();
                    String piloto = elemento.getElementsByTagName("piloto").item(0).getTextContent();
                    System.out.println("ID: " + id + " | Nombre: " + nombre + " | Piloto: " + piloto);
                }
            }
            //SAXX
            SAXParserFactory saxfactory = SAXParserFactory.newInstance();          //Igual que antes, crea una fábrica para poder construir nuestro parser SAX.
            SAXParser saxParser = saxfactory.newSAXParser();                       //Usando la fabrica obtenemos un parser, que recorre el XML, en lugar de cargarlo como el DOM.
            
            DefaultHandler manejador = new DefaultHandler() {                      //Decidirá que hacer con lo establecido más adelante
                private boolean esNombre = false;

            @Override
                public void startElement(String uri, String localName, String qName, Attributes attributes){ //Se ejecuta automáticamente cada vez que SAX encuentra una etiqueta de apertura. Registra los datos de la nave
                    if (qName.equalsIgnoreCase("nave")) {
                        String clase = attributes.getValue("clase");
                        System.out.print("Clase de la nave: " + clase);
                    } else if (qName.equalsIgnoreCase("nombre")) {
                        esNombre = true;
                    }
                }
                
            @Override
                public void characters(char[] ch, int start, int length){           //Se ejecuta cuando SAX encuentra texto dentro de una etiqueta.
                    if (esNombre) {
                        String texto = new String(ch, start, length).trim();       //Convierte los caracteres encontrados en un String y elimina los espacios sobrantes.   
                        if (!texto.isEmpty()) {
                        System.out.print(" | Nombre: " + texto);
                        }
                    }
                }

                @Override
                public void endElement(String uri, String localName, String qName) { //Se ejecuta cuando SAX encuentra una etiqueta de cierre.
                    if (qName.equalsIgnoreCase("nombre")) {
                    esNombre = false;                                                //Como ha salido ya el nombre, deja de buscar el texto.
                }
                }
            };

            saxParser.parse(new File("imperio.xml"), manejador);                     //Recorre el XML llamando manejador, que se ha creado anteriormente.
            
            //Binding
            Personaje personaje = new Personaje(
                    "Luke Skywalker",
                    "Comandante / Caballero Jedi"
            );
                                                                                   
            JAXBContext contexto = JAXBContext.newInstance(Personaje.class);        //Crea el contexto JAXB para la clase Personaje
  
 
                                                                                     
            Marshaller marshaller = contexto.createMarshaller();                    //Crear el Marshaller, que convierte los objetos a XML.

            
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);          //Formatea el XML para que sea legible

            FileOutputStream salida = new FileOutputStream("rebelde.xml");           //Creamos el archivo donde se guardará el XML.

            marshaller.marshal(personaje, salida);                                   //Convierte el objeto personaje en XML y lo escribe en el archivo.

            salida.close();
            System.out.println("Archivo rebelde.xml creado correctamente.");
        }catch(Exception e){
            System.out.print(e.getMessage());
        }
    }
}
